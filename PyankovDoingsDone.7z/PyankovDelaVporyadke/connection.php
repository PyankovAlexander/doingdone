<?php

$ip_bd = "127.0.0.1";
$user_bd = "root";
$password_bd = "root";
$name_bd = "schema";

$con = mysqli_connect($ip_bd, $user_bd, $password_bd, $name_bd);


